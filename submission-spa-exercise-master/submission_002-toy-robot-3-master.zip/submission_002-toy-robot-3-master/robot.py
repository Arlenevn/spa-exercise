import sys 


def robot_start():
    """This is the entry function, do not change"""
    robot_name = get_name()
    run_game(robot_name)


def get_name():
    '''Collects user input'''

    robot_name = input("What do you want to name your robot? ")

    print (robot_name.upper() + ": Hello kiddo!")

    return robot_name.upper()


def get_command(robot_name):
    
    command_input_lowered = input(robot_name + ": What must I do next? ")
    
    command_input = command_input_lowered.lower()

    validation_result = validate_command(command_input, command_input_lowered, robot_name)

    while validation_result == "No":
        command_input = input(robot_name + ": What must I do next? ").lower()
        validation_result = validate_command(command_input, command_input_lowered, robot_name)

    return command_input

def stored_history(command, stored_commands):

    first_input = command.split()[0]

    if first_input in ["right", "left", "forward", "back", "sprint"]:
        stored_commands.append(command)
    return stored_commands


def validate_command(command_input, command_input_lowered, robot_name):

    command_input_list = command_input.split()

    valid_one_word_commands = ["off", "help", "right", "left","replay"]
    valid_two_word_commands = ["forward", "back", "sprint", "replay"] 

    if command_input_list[0] == "replay" and len(command_input_list) == 3 and (command_input_list[1].isdigit() or command_input_list[2].isdigit()):
        return "Yes"

    if command_input_list[0] == "replay" and len(command_input_list) == 2 and (len(command_input_list[1].split("-")) == 2):
        return "Yes"

    elif command_input == "replay" or command_input == "replay silent" or command_input == "replay reversed" or command_input == "replay reversed silent":
        return "Yes"
    
    elif len(command_input_list) == 1 and command_input in valid_one_word_commands:
        return "Yes" 

    elif len(command_input_list) == 2 and command_input_list[1].isdigit() and command_input_list[0] in valid_two_word_commands:
        return "Yes"

    else: 
        print (robot_name + ": Sorry, I did not understand " + "'" + command_input_lowered  + "'.")
        return "No"


def run_game(robot_name):
    
    x = 0 
    y = 0
    quadrant = 0

    stored_commands = []
    
    keep_going = True

    while keep_going == True:
        command = get_command(robot_name)
        stored_commands = stored_history(command, stored_commands)

        #replay? if command is replay then retrive command and execute command (arg)

        x, y, quadrant, keep_going = execute_command(x, y, quadrant, command, robot_name, keep_going, stored_commands)
    exit    


def execute_command(x, y, quadrant, command, robot_name, keep_going, stored_commands):
 
    command_input_list = command.split()
    action = command_input_list[0] 

    if action == "replay":

        if len(command_input_list) == 1: 
            num_replay_commands = str(len(stored_commands))
            x, y, quadrant, keep_going = replay_command(command,x, y, quadrant, num_replay_commands, robot_name, stored_commands, keep_going) 

        elif len(command_input_list) == 2: 
            if command_input_list[1] == "silent":
                num_replay_commands = len(stored_commands)
                x, y, quadrant, keep_going = replay_silent(command,x, y, quadrant, num_replay_commands, robot_name, stored_commands, keep_going)
        
            elif command_input_list[1] == "reversed":
               num_replay_commands = len(stored_commands) 
               x, y, quadrant, keep_going = replay_reversed(command,x, y, quadrant, num_replay_commands, robot_name, stored_commands, keep_going)

            elif command_input_list[1].isdigit():
                num_replay_commands = command_input_list[1]
                x, y, quadrant, keep_going = replay_command(command,x, y, quadrant, num_replay_commands, robot_name, stored_commands, keep_going) 

            elif len(command_input_list[1].split("-")) == 2:
                num_replay_commands = command_input_list[1]
                x, y, quadrant, keep_going = replay_command(command,x, y, quadrant, num_replay_commands, robot_name, stored_commands, keep_going) 


        elif len(command_input_list) == 3:
            if "reversed" in command_input_list and "silent" in command_input_list:
               num_replay_commands = len(stored_commands) 
               x, y, quadrant, keep_going = replay_reversed_silent(command,x, y, quadrant, num_replay_commands, robot_name, stored_commands, keep_going)

            elif "reversed" in command_input_list and "silent" not in command_input_list:
                if command_input_list[1].isdigit():
                    num_replay_commands = command_input_list[1]
                elif command_input_list[2].isdigit():
                    num_replay_commands = command_input_list[2]
                x, y, quadrant, keep_going = replay_reversed(command,x, y, quadrant, num_replay_commands, robot_name, stored_commands, keep_going)

            elif "silent" in command_input_list and "reversed" not in command_input_list:
                if command_input_list[1].isdigit():
                    num_replay_commands = command_input_list[1]
                elif command_input_list[2].isdigit():
                    num_replay_commands = command_input_list[2]
                x, y, quadrant, keep_going = replay_silent(command,x, y, quadrant, num_replay_commands, robot_name, stored_commands, keep_going)        
   
    elif len(command_input_list) == 1:
        if action == "off":
            off_command(robot_name)
            keep_going = False
        elif action == "left":
            quadrant = left_command(x, y, quadrant, robot_name)
        elif action == "right":
            quadrant = right_command(x, y, quadrant, robot_name)
        elif action == "help":
            help_command(robot_name)
        
    elif len(command_input_list) == 2:
        action = command_input_list[0]
        steps = command_input_list[1]
        steps = int(steps)
        if action == "forward": 
            x, y = forward_command(x, y, quadrant, steps, robot_name)
        elif action == "back":
            x, y = back_command(x, y, quadrant, steps, robot_name)
        elif action == "sprint":
            x, y = sprint_command(x, y, quadrant, steps, robot_name)
    
    if action == "help" or action == "off": 
        return x, y, quadrant, keep_going
    elif action != "help" or action != "off":
        print (" > " + robot_name + " now at position " + "(" + str(x) + "," + str(y) + ").")

    return x, y, quadrant, keep_going


def off_command(robot_name):
    print (robot_name + ": Shutting down..")
    exit


def help_command(robot_name):

    print("""I can understand these commands:
OFF  - Shut down robot
HELP - provide information about commands
FORWARD + number of forward movements(i.e 'Forward 10') - Move robot forward
BACK + number of backward movements(i.e 'Back 10') - Move robot back
RIGHT - Right-turn(turn robot by 90 degrees to the right)
LEFT - Left-turn(turn robot by 90 degrees to the left)
SPRINT - Gives robot a short burst of speed and some extra distance
""")


def forward_command(x, y, quadrant, steps, robot_name):

    default_x_value = x
    default_y_value = y

    if quadrant == 0: 
            y += steps
    elif quadrant == 1 or quadrant == -3:
            x += steps
    elif quadrant == 2 or quadrant == -2: 
            y -= steps 
    elif quadrant == 3 or quadrant == -1:
            x -= steps

    if (y >200 or y < -200) or (x >100 or x < -100):
        print (robot_name + ": Sorry, I cannot go outside my safe zone.")
        return default_x_value, default_y_value
    else:
        print (" > " + robot_name + " moved forward by " + str(steps) + " steps.") 
        return x, y  


def back_command(x, y, quadrant, steps, robot_name):

    default_x_value = x
    default_y_value = y

    if quadrant == 0: 
        y -= steps
    elif quadrant == 1 or quadrant == -3:
        x -= steps
    elif quadrant == 2 or quadrant == -2: 
        y += steps 
    elif quadrant == 3 or quadrant == -1:
        x += steps

    if (y >200 or y < -200) or (x >100 or x < -100):
        print (robot_name + ": Sorry, I cannot go outside my safe zone.")
        return default_x_value, default_y_value
    else:
        print (" > " + robot_name + " moved back by " + str(steps) + " steps.") 
        return x, y


def right_command(x, y, quadrant, robot_name):
    
    quadrant += 1
    
    print (" > " + robot_name + " turned right.") 

    return quadrant


def left_command(x, y , quadrant, robot_name):
    
    quadrant -= 1

    print (" > " + robot_name + " turned left.") 
    
    return quadrant


def sprint_command(x, y, quadrant, steps, robot_name):

    default_x_value = x
    default_y_value = y

    if steps == 0: 
        return x,y 
    else: 
        x, y = forward_command (x, y, quadrant, steps, robot_name)
        steps -= 1 

        if (y >200 or y < -200) or (x >100 or x < -100):
            return default_x_value, default_y_value
        
    return sprint_command (x, y, quadrant, steps, robot_name)


def replay_command(command,x, y, quadrant, num_replay_commands, robot_name, stored_commands, keep_going): 
    
    if num_replay_commands.isdigit():
        N = int(num_replay_commands)
        M = 0
        adjusted_history = stored_commands[-N:]

    elif len(num_replay_commands.split("-")) == 2:
        N = int(num_replay_commands.split("-")[0])
        M = int(num_replay_commands.split("-")[1])

        adjusted_history = stored_commands[-N:-M]


    if 1 <= N <= len(stored_commands):

        for command_in_history in adjusted_history:
            x, y, quadrant, keep_going = execute_command(x, y, quadrant, command_in_history, robot_name, keep_going, stored_commands)

        print (" > " + robot_name + " replayed " + str(N-M) + " commands.")

    else:
         print (" > " + robot_name + " replayed 0 commands.")

    return x, y, quadrant, keep_going


def replay_silent(command,x, y, quadrant, num_replay_commands, robot_name, stored_commands, keep_going):

    old_output = sys.stdout
    sys.stdout = open("alternative_print_store","w")
    N = int(num_replay_commands)

    if 1 <= N <= len(stored_commands):
        for command_in_history in stored_commands[-N:]:
            x, y, quadrant, keep_going = execute_command(x, y, quadrant, command_in_history, robot_name, keep_going, stored_commands)
        sys.stdout = old_output

        print (" > " + robot_name + " replayed " + str(N) + " commands silently.")

    else:
         print (" > " + robot_name + " replayed 0 commands silently.")    

    return x, y, quadrant, keep_going


def replay_reversed(command,x, y, quadrant, num_replay_commands, robot_name, stored_commands, keep_going):

    replay_back =  list(reversed(stored_commands))
    N = int(num_replay_commands)

    if 1 <= N <= len(stored_commands):
        for command_in_history in replay_back[-N:]:
            x, y, quadrant, keep_going = execute_command(x, y, quadrant, command_in_history, robot_name, keep_going, stored_commands)

        print (" > " + robot_name + " replayed " + str(N) + " commands in reverse.")

    else:
         print (" > " + robot_name + " replayed 0 commands in reverse.")

    return x, y, quadrant, keep_going


def replay_reversed_silent(command,x, y, quadrant, num_replay_commands, robot_name, stored_commands, keep_going):

    old_output = sys.stdout
    sys.stdout = open("alternative_print_store","w")
    N = int(num_replay_commands)

    replay_back =  list(reversed(stored_commands))

    if 1 <= N <= len(stored_commands):
        for command_in_history in replay_back[-N:]:
            x, y, quadrant, keep_going = execute_command(x, y, quadrant, command_in_history, robot_name, keep_going, stored_commands)
        sys.stdout = old_output

        print (" > " + robot_name + " replayed " + str(N) + " commands in reverse silently.")

    else:
        print (" > " + robot_name + " replayed 0 commands silently.")    

    return x, y, quadrant, keep_going

if __name__ == "__main__":
    robot_start()
    