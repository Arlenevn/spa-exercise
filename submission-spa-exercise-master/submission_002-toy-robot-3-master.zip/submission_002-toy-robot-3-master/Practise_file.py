stored_commands = ["forward 1", "forward 2", "forward 3", "forward 4", "forward 5"]

arg = "5-2"
print(arg.isdigit())



# for command in stored_commands[-N:]:
#     print(command)